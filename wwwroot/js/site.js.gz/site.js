function toggleTheme() {
    document.documentElement.classList.toggle('dark-theme');
}
